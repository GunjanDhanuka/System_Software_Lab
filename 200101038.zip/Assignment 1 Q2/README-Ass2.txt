QUESTION 2
------------


The Shell Script is in 200101038_Assign01_Q2.sh file and the alphabet sequence is stored in the data.txt file.

Steps to run the script:
1. Open terminal in the folder and type the following commands
2. $ chmod +x 200101038_Assign01_Q2.sh (to make the shell script executable)
3. ./200101038_Assign01_Q2.sh <count> <length> < <file with data>


Eg:
$ chmod +x 200101038_Assign01_Q2.sh
$ ./200101038_Assign01_Q2.sh 4 10 < data.txt
Output:
q
quuu
quuubbb
quuubbbu
quuubbbuy
quuubbbuyk


Note:
-----

**PLEASE MAKE SURE THAT THE data.txt file contains more than one unique alphabets (as instructed by Pinaki Sir).
**Redirection operator has to be used on the command line as suggested by Pinaki Sir.
**The output is based on random numbers so it will vary in different executions.
**THE data.txt file can be changed to check for other test cases as well


Gunjan Dhanuka
Roll - 200101038
